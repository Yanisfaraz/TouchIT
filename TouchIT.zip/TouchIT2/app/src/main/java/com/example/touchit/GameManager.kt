package com.example.touchit

import android.content.Context
import android.content.Context.MODE_PRIVATE

class GameManager(
    private val context: Context,
    private val uiManager: IUIManager,
    private val targetManager: ITargetManager
) : IGameManager {
    override var gameActive = false
    override var score = 0
    override var timeLeft = 30
    override var lives = 3

    override fun startNewGame() {
        gameActive = true
        score = 0
        timeLeft = 30
        lives = 3

        uiManager.updateUI(score, timeLeft, lives)
        uiManager.startTimer()

        // Générer les cibles initiales
        targetManager.generateNewTarget(TargetType.RED_MOVING)
        targetManager.generateNewTarget(TargetType.BLUE_STATIC)
        targetManager.generateNewTarget(TargetType.PINK_SPLIT)
    }

    override fun updateScore(points: Int) {
        if (gameActive) {
            score += points
            uiManager.updateUI(score, timeLeft, lives)
        }
    }

    override fun loseLife() {
        lives--
        uiManager.updateUI(score, timeLeft, lives)
        if (lives <= 0) {
            showGameOver()
        } else {
            uiManager.blinkLife()
        }
    }

    override fun showGameOver() {
        gameActive = false
        uiManager.stopTimer()
        val highScore = getHighScore()
        if (score > highScore) {
            saveHighScore(score)
        }
        uiManager.showGameOver(score, getHighScore())
    }

    private fun getHighScore(): Int {
        return context.getSharedPreferences("game_prefs", MODE_PRIVATE)
            .getInt("high_score", 0)
    }

    private fun saveHighScore(score: Int) {
        context.getSharedPreferences("game_prefs", MODE_PRIVATE)
            .edit()
            .putInt("high_score", score)
            .apply()
    }

    override fun cleanup() {
        gameActive = false
        targetManager.cleanup()
        uiManager.cleanup()
    }
}