package com.example.touchit

import android.content.Context
import android.graphics.drawable.ShapeDrawable
import android.graphics.drawable.shapes.OvalShape
import android.os.Handler
import android.view.View
import android.widget.FrameLayout
import kotlin.math.cos
import kotlin.math.sin

class TargetManager(
    private val context: Context,
    private val gameFrame: FrameLayout,
    private val handler: Handler,
    private val onTargetHit: (Int) -> Unit
) : ITargetManager {

    private val targets = mutableListOf<Pair<View, Target>>()
    private val targetFactory = TargetFactory()
    private var isRunning = true

    init {
        startUpdateLoop()
    }

    private fun createTargetView(target: Target): View {
        return View(context).apply {
            layoutParams = FrameLayout.LayoutParams(100, 100)
            background = ShapeDrawable(OvalShape()).apply {
                paint.color = target.color
            }
            tag = target
            setOnClickListener { onTargetClicked(this) }
        }
    }

    override fun generateNewTarget(type: TargetType) {
        if (!isRunning) return

        val target = targetFactory.createTarget(type)
        gameFrame.post {
            val targetView = createTargetView(target).apply {
                x = (100..maxOf(100, gameFrame.width - 200)).random().toFloat()
                y = (100..maxOf(100, gameFrame.height - 200)).random().toFloat()
            }

            gameFrame.addView(targetView)
            targets.add(Pair(targetView, target))
        }
    }

    override fun onTargetClicked(view: View) {
        val target = view.tag as Target
        when (target.type) {
            TargetType.PINK_SPLIT -> {
                gameFrame.removeView(view)
                targets.removeAll { it.first == view }
                onTargetHit(target.points)
                generateNewTarget(TargetType.PURPLE_MOVING)
                generateNewTarget(TargetType.PURPLE_MOVING)
            }
            else -> {
                gameFrame.removeView(view)
                targets.removeAll { it.first == view }
                onTargetHit(target.points)
            }
        }
    }

    override fun updateTargets() {
        if (!isRunning) return

        val frameWidth = maxOf(1, gameFrame.width)
        val frameHeight = maxOf(1, gameFrame.height)

        targets.forEach { (view, target) ->
            if (target.type == TargetType.RED_MOVING || target.type == TargetType.PURPLE_MOVING) {
                val radians = Math.toRadians(target.direction.toDouble())
                var newX = view.x + (target.speed * cos(radians)).toFloat()
                var newY = view.y + (target.speed * sin(radians)).toFloat()

                if (newX <= 0 || newX >= frameWidth - 100) {
                    val newTarget = target.copy(direction = 180 - target.direction)
                    view.tag = newTarget
                    newX = newX.coerceIn(0f, (frameWidth - 100).toFloat())
                }
                if (newY <= 0 || newY >= frameHeight - 100) {
                    val newTarget = target.copy(direction = 360 - target.direction)
                    view.tag = newTarget
                    newY = newY.coerceIn(0f, (frameHeight - 100).toFloat())
                }

                view.x = newX
                view.y = newY
            }
        }
    }

    private fun startUpdateLoop() {
        handler.post(object : Runnable {
            override fun run() {
                if (isRunning) {
                    updateTargets()
                    handler.postDelayed(this, 16)
                }
            }
        })
    }

    override fun cleanup() {
        isRunning = false
        handler.removeCallbacksAndMessages(null)
        targets.forEach { (view, _) ->
            gameFrame.removeView(view)
        }
        targets.clear()
    }
}