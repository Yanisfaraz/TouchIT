package com.example.touchit

interface IUIManager {
    fun updateUI(score: Int, timeLeft: Int, lives: Int)
    fun startTimer()
    fun stopTimer()
    fun blinkLife()
    fun showGameOver(finalScore: Int, highScore: Int)
    fun cleanup()
}