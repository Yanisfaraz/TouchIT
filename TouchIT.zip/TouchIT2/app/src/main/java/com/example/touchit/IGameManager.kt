package com.example.touchit

interface IGameManager {
    fun startNewGame()
    fun updateScore(points: Int)
    fun loseLife()
    fun showGameOver()
    fun cleanup()
    val gameActive: Boolean
    val score: Int
    val timeLeft: Int
    val lives: Int
}