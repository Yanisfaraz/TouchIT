package com.example.touchit

import kotlin.random.Random

class TargetFactory {
    private val random = Random(System.currentTimeMillis())

    fun createTarget(type: TargetType): Target {
        return when (type) {
            TargetType.RED_MOVING -> createRedTarget()
            TargetType.BLUE_STATIC -> createBlueTarget()
            TargetType.PINK_SPLIT -> createPinkTarget()
            TargetType.PURPLE_MOVING -> createPurpleTarget()
        }
    }

    private fun createRedTarget() = Target(
        type = TargetType.RED_MOVING,
        points = TargetTypes.targetPoints[TargetType.RED_MOVING]!!,
        color = TargetTypes.targetColors[TargetType.RED_MOVING]!!,
        speed = TargetTypes.targetSpeeds[TargetType.RED_MOVING]!!,
        direction = random.nextFloat() * 360
    )

    private fun createBlueTarget() = Target(
        type = TargetType.BLUE_STATIC,
        points = TargetTypes.targetPoints[TargetType.BLUE_STATIC]!!,
        color = TargetTypes.targetColors[TargetType.BLUE_STATIC]!!
    )

    private fun createPinkTarget() = Target(
        type = TargetType.PINK_SPLIT,
        points = TargetTypes.targetPoints[TargetType.PINK_SPLIT]!!,
        color = TargetTypes.targetColors[TargetType.PINK_SPLIT]!!
    )

    private fun createPurpleTarget() = Target(
        type = TargetType.PURPLE_MOVING,
        points = TargetTypes.targetPoints[TargetType.PURPLE_MOVING]!!,
        color = TargetTypes.targetColors[TargetType.PURPLE_MOVING]!!,
        speed = TargetTypes.targetSpeeds[TargetType.PURPLE_MOVING]!!,
        direction = random.nextFloat() * 360
    )
}