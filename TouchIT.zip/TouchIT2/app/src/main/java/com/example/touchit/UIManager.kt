package com.example.touchit

import android.app.Activity
import android.os.Handler
import android.os.Looper
import android.view.View
import android.widget.FrameLayout
import android.widget.TextView

class UIManager(
    private val activity: Activity,
    private val gameFrame: FrameLayout,
    private val scoreTextView: TextView,
    private val timerTextView: TextView,
    private val livesTextView: TextView,
    private val gameOverLayout: View
) : IUIManager {
    private val handler = Handler(Looper.getMainLooper())
    private var timerRunnable: Runnable? = null

    override fun updateUI(score: Int, timeLeft: Int, lives: Int) {
        activity.runOnUiThread {
            scoreTextView.text = "Score: $score"
            timerTextView.text = "Time: $timeLeft"
            livesTextView.text = "Lives: $lives"
        }
    }

    override fun startTimer() {
        timerRunnable = object : Runnable {
            override fun run() {
                // Implémentez la logique du timer ici
                handler.postDelayed(this, 1000)
            }
        }
        handler.post(timerRunnable!!)
    }

    override fun stopTimer() {
        timerRunnable?.let { handler.removeCallbacks(it) }
    }

    override fun blinkLife() {
        // Implémentez l'animation de clignotement
    }

    override fun showGameOver(finalScore: Int, highScore: Int) {
        activity.runOnUiThread {
            gameFrame.addView(gameOverLayout)
            // Implémentez l'affichage du game over
        }
    }

    override fun cleanup() {
        stopTimer()
    }
}