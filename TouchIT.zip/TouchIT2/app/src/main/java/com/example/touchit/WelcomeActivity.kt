package com.example.touchit

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.View
import android.widget.ImageView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class WelcomeActivity : AppCompatActivity() {
    private var logoClicks = 0
    private val clickHandler = Handler(Looper.getMainLooper())
    private val resetClicksRunnable = Runnable { logoClicks = 0 }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_welcome)

        // Cacher la barre de statut
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_FULLSCREEN

        try {
            val logoImageView = findViewById<ImageView>(R.id.logoImageView)
            setupLogoClickListener(logoImageView)
        } catch (e: Exception) {
            Log.e("WelcomeActivity", "Erreur lors de l'initialisation", e)
            showErrorAndFinish()
        }
    }

    private fun setupLogoClickListener(logoImageView: ImageView) {
        logoImageView.setOnClickListener {
            try {
                handleLogoClick()
            } catch (e: Exception) {
                Log.e("WelcomeActivity", "Erreur lors du clic sur le logo", e)
                showErrorAndFinish()
            }
        }
    }

    private fun handleLogoClick() {
        logoClicks++
        if (logoClicks >= 3) {
            startMainActivity()
        } else {
            resetClicksAfterDelay()
        }
    }

    private fun startMainActivity() {
        logoClicks = 0
        val intent = Intent(this, MainActivity::class.java)
        startActivity(intent)
        finish()
    }

    private fun resetClicksAfterDelay() {
        clickHandler.removeCallbacks(resetClicksRunnable)
        clickHandler.postDelayed(resetClicksRunnable, 2000)
    }

    private fun showErrorAndFinish() {
        Toast.makeText(this, "Une erreur est survenue", Toast.LENGTH_SHORT).show()
        finish()
    }

    override fun onDestroy() {
        super.onDestroy()
        clickHandler.removeCallbacks(resetClicksRunnable)
    }
}