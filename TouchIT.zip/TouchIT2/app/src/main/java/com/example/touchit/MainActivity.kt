package com.example.touchit

import android.graphics.drawable.ShapeDrawable
import android.graphics.drawable.shapes.OvalShape
import android.graphics.Color
import android.os.Bundle
import android.os.CountDownTimer
import android.view.View
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.random.Random

class MainActivity : AppCompatActivity() {
    private lateinit var scoreTextView: TextView
    private lateinit var timerTextView: TextView
    private lateinit var livesTextView: TextView
    private lateinit var hearts: List<ImageView>
    private var score = 0
    private var lives = 3
    private var isGameActive = false
    private lateinit var gameFrame: FrameLayout
    private var countDownTimer: CountDownTimer? = null
    private var timeLeft = 30

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        initializeViews()
        setupGame()
        startGame()
    }

    private fun initializeViews() {
        scoreTextView = findViewById(R.id.scoreTextView)
        timerTextView = findViewById(R.id.timerTextView)
        livesTextView = findViewById(R.id.livesTextView)
        gameFrame = findViewById(R.id.gameFrame)
        hearts = listOf(
            findViewById(R.id.heart1),
            findViewById(R.id.heart2),
            findViewById(R.id.heart3)
        )
    }

    private fun setupGame() {
        score = 0
        lives = 3
        updateScoreDisplay()
        updateLivesDisplay()
        gameFrame.setOnClickListener {
            if (isGameActive) {
                reduceLife()
            }
        }
    }

    private fun startGame() {
        isGameActive = true
        startTimer()
        spawnTargets()
    }

    private fun startTimer() {
        countDownTimer = object : CountDownTimer(30000, 1000) {
            override fun onTick(millisUntilFinished: Long) {
                timeLeft = (millisUntilFinished / 1000).toInt()
                timerTextView.text = "Time: $timeLeft"
            }

            override fun onFinish() {
                stopGame()
            }
        }.start()
    }

    private fun spawnTargets() {
        lifecycleScope.launch {
            while (isGameActive) {
                createTarget()
                delay(Random.nextLong(800, 1500))
            }
        }
    }

    private fun createTarget() {
        val targetSize = 100
        val target = View(this).apply {
            background = createTargetDrawable()
            x = Random.nextFloat() * (gameFrame.width - targetSize)
            y = Random.nextFloat() * (gameFrame.height - targetSize)
            layoutParams = FrameLayout.LayoutParams(targetSize, targetSize)

            setOnClickListener {
                if (isGameActive) {
                    score++
                    updateScoreDisplay()
                    gameFrame.removeView(this)
                }
            }
        }

        gameFrame.post {
            gameFrame.addView(target)
        }

        lifecycleScope.launch {
            delay(2000)
            gameFrame.post {
                if (target.parent != null) {
                    gameFrame.removeView(target)
                }
            }
        }
    }

    private fun createTargetDrawable(): ShapeDrawable {
        return ShapeDrawable(OvalShape()).apply {
            paint.color = Color.RED
        }
    }

    private fun updateScoreDisplay() {
        scoreTextView.text = "Score: $score"
    }

    private fun updateLivesDisplay() {
        livesTextView.text = "Lives: $lives"
        hearts.forEachIndexed { index, heart ->
            heart.visibility = if (index < lives) View.VISIBLE else View.INVISIBLE
        }
    }

    private fun reduceLife() {
        lives--
        updateLivesDisplay()
        if (lives <= 0) {
            stopGame()
        }
    }

    private fun stopGame() {
        isGameActive = false
        countDownTimer?.cancel()
        gameFrame.removeAllViews()
    }

    override fun onDestroy() {
        super.onDestroy()
        countDownTimer?.cancel()
    }
}