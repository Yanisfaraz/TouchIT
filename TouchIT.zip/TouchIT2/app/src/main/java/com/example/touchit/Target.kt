package com.example.touchit

import android.graphics.Color

enum class TargetType {
    RED_MOVING,    // Cible rouge mobile
    BLUE_STATIC,   // Cible bleue statique
    PINK_SPLIT,    // Cible rose qui se divise
    PURPLE_MOVING  // Cible mauve mobile (issue de la division)
}

data class Target(
    val type: TargetType,
    val points: Int,
    val color: Int,
    val speed: Float = 0f,
    val direction: Float = 0f,
    val displayTime: Long = 2000L // Temps d'affichage en millisecondes
)

object TargetTypes {
    // Points attribués pour chaque type de cible
    val targetPoints = mapOf(
        TargetType.RED_MOVING to 4,    // Cible rouge = 4 points
        TargetType.BLUE_STATIC to 2,   // Cible bleue = 2 points
        TargetType.PINK_SPLIT to 1,    // Cible rose = 1 point
        TargetType.PURPLE_MOVING to 3  // Cible mauve = 3 points
    )

    // Couleurs associées à chaque type de cible
    val targetColors = mapOf(
        TargetType.RED_MOVING to Color.RED,
        TargetType.BLUE_STATIC to Color.BLUE,
        TargetType.PINK_SPLIT to Color.MAGENTA,
        TargetType.PURPLE_MOVING to Color.parseColor("#800080") // Violet/Mauve
    )

    // Vitesses de déplacement pour les cibles mobiles
    val targetSpeeds = mapOf(
        TargetType.RED_MOVING to 5f,
        TargetType.PURPLE_MOVING to 7f
    )
}