package com.example.touchit

import android.view.View

interface ITargetManager {
    fun generateNewTarget(type: TargetType)
    fun onTargetClicked(view: View)
    fun updateTargets()
    fun cleanup()
}