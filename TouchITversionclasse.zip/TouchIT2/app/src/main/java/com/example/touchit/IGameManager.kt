package com.example.touchit

interface IGameManager {
    fun startNewGame()
    fun stopGame()
    fun cleanup()
}